package com.hasan.sharebook.database

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.compose.ui.text.input.TextFieldValue
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database


class Database {
    companion object {
        val ref = Firebase.database.reference.child("users")
        val users = FirebaseDatabase.getInstance().reference.child("users")

        fun setUser(user: User) {
            user.id?.let { ref.child(it).setValue(user) }
        }
        fun checkUser(user: String, password: String, callback: (String) -> Unit) {
            users.child(user + "_123").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists() && dataSnapshot.getValue(User::class.java)!!.password == password) {
                        callback("Logged in Successfully")
                    } else {
                        callback("Incorrect Username or Password")
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    callback("Database Error")
                }
            })
        }
    }
}