package com.hasan.sharebook.screens


import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.rememberScrollableState
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.BottomNavigationDefaults
import androidx.compose.material3.BottomAppBarDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.hasan.sharebook.R
import com.hasan.sharebook.screens.ui.theme.Blue
import com.hasan.sharebook.screens.ui.theme.Blue_1

@Composable
fun Profile() {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp).padding()
                .verticalScroll(
                    rememberScrollState()
                )
        ) {
            Card(
                modifier = Modifier.padding(top = 30.dp),
                shape = RoundedCornerShape(50.dp),
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_1),
                    contentDescription = "",
                    modifier = Modifier.size(100.dp),
                    alignment = Alignment.Center
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
            var user_name = remember {
                mutableStateOf("Shohrux")
            }
            var user_email = remember {
                mutableStateOf("Sharipov")
            }
            var user_number = remember {
                mutableStateOf("998981100107")
            }
            var user_location = remember {
                mutableStateOf("Tashkent city")
            }
            OutlinedTextField(
                value = user_name.value,
                onValueChange = { newText -> user_name.value = newText },
                label = {
                    Text(
                        text = "Name"
                    )
                }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(30.dp))
            OutlinedTextField(
                value = user_email.value,
                onValueChange = { newText -> user_email.value = newText },
                label = { Text(text = "Email", fontSize = 18.sp) }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(30.dp))
            OutlinedTextField(
                value = user_number.value,
                onValueChange = { newText -> user_number.value = newText },
                label = { Text(text = "Phone number", fontSize = 18.sp) }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(30.dp))
            OutlinedTextField(
                value = user_location.value,
                onValueChange = { newText -> user_location.value = newText },
                label = { Text(text = "Location", fontSize = 18.sp) }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(24.dp))
            GradientButton(
                text = "Save Changes",
                gradient = Brush.horizontalGradient(listOf(Blue_1, Blue)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),

                )
        }
    }
}