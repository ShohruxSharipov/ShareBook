package com.hasan.sharebook.database

data class Book(val name:String,val description:String,val status:Boolean,val genre:String)
